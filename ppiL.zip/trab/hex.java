package trab;
import java.util.Scanner;
public class hex{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Selecione uma das opções: ");
		int op = sc.nextInt();
		
		System.out.println("Informe um número: ");
		int num = sc.nextInt();
		int rs = 0, resto = 0;
		if(op == 1) {
			rs = num / 16;
			resto = num % 16;
		}
	}
}