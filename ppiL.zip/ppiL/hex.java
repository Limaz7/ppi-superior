package ppiL;

import java.util.Scanner;
import java.lang.Math;
import java.lang.Character;

public class hex {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Selecione uma das opções (1 - hex p/ dec, 2 - dec p/ hex, 3 - hex p/ bin, 4 - bin p/ hex): ");
		int op = sc.nextInt();

		System.out.println("Informe um número: ");
		String num = sc.next();
		
		int resto, a;
		double resultadoPotencia = 0, agregarValor = 0, result = 0;
		resto = a = 0;

		if (op == 1) {
			
			for (a = 0; a < num.length(); a++) {
				char numeroSeparado = num.charAt(a);
				resultadoPotencia = Math.pow(16, num.length() - 1 - a);
				int valor;
				if (Character.isDigit(numeroSeparado)) {
					valor = Character.getNumericValue(numeroSeparado);
				} else {
					valor = Character.toUpperCase(numeroSeparado) - 'A' + 10;
				}
				result = valor * resultadoPotencia;
				agregarValor += result;
			}
			System.out.print("Decimal: " + agregarValor);
			
		} else if (op == 2) {

			int numeroInteiro = Integer.valueOf(num);
			String convert = "";
			
			while(numeroInteiro > 0) {
				resto = numeroInteiro % 16;
				String restoHex;
				if (resto >= 10) {
					restoHex = String.valueOf((char)('A' + (resto - 10)));
				} else {
					restoHex = String.valueOf(resto);
				}
				numeroInteiro /= 16;
				System.out.print("Resultado: " + numeroInteiro + " Resto: " + restoHex + "\n");
				convert = restoHex + convert;
			}	
			System.out.print("Hexadecimal: " + convert);

		} else if (op == 3) {
			
			String numeroInvertido = "";
			
			for (a = 0; a < num.length(); a++) {
				char numeroSeparado = num.charAt(a);
				resultadoPotencia = Math.pow(16, num.length() - 1 - a);
				int valor;
				if (Character.isDigit(numeroSeparado)) { 
					valor = Character.getNumericValue(numeroSeparado);
				} else {
					valor = Character.toUpperCase(numeroSeparado) - 'A' + 10;
				}
				result = valor * resultadoPotencia;
				agregarValor += result;
			}
			
			int numeroInteiro = (int) agregarValor;
			
			while(numeroInteiro > 0) {
				resto = numeroInteiro % 2;
				numeroInvertido = resto + numeroInvertido;
				numeroInteiro /= 2;
			}
			
			System.out.println("Binario: " + numeroInvertido);

		} else if (op == 4) {
			
			int decimal = 0;
	        int potencia = 1;
	        String hexa = "";
	        String restoHex = ""; 
	        int indice = num.length() - 1;
				
	        while (indice >= 0) {
                char digito = num.charAt(indice);
                if (digito == '1') {
                    decimal += potencia;
                }
                potencia *= 2;
                indice--;
            }
				
				potencia *= 2;
				
				if (decimal == 0) {
					hexa = "0";
					
				} else {
					
					while(decimal > 0) {
						resto = decimal % 16;
						
						if (resto >= 10) {
							
							restoHex = String.valueOf((char)('A' + (resto - 10)));
							
						} else {
							
							restoHex = String.valueOf(resto);
							
						}
						hexa = restoHex + hexa;
						decimal /= 16;
					}
					
				}
				
				System.out.println(hexa);
				
			}
		sc.close();
		}
	}