package trab;

import java.util.Scanner;
import java.lang.Math;
import java.lang.Character;

public class hex {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Selecione uma das opções (1 - hex p/ dec, 2 - dec p/ hex): ");
		int op = sc.nextInt();

		System.out.println("Informe um número: ");
		String num = sc.next();
		int qtdc = num.length();
		int resto, i, a;
		double pot = 0, tot = 0, result = 0;
		resto = i = a = 0;

		if (op == 1) {
			System.out.println(qtdc + " " + num);
			for (a = 0; a < qtdc; a++) {
				char litNum = num.charAt(a);
				pot = Math.pow(16, qtdc - 1 - a);
				System.out.print(litNum + " * " + pot + " = " + "\n");
				int valor;
				if (Character.isDigit(litNum)) {
					valor = Character.getNumericValue(litNum);
				} else {
					valor = Character.toUpperCase(litNum) - 'A' + 10;
				}

				result = valor * pot;
				System.out.println(result);
				tot += result;
				/*
				 * num = num / 16;
				 * resto = num % 16;
				 * System.out.println(num);
				 * System.out.println(resto);
				 */
			}
			System.out.println(tot);
		}
	}
}