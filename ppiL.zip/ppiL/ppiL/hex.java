package ppiL.ppiL;

import java.util.Scanner;
import java.lang.Math;
import java.lang.Character;

public class hex {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringBuilder sb = new StringBuilder();

		System.out.println("Selecione uma das opções (1 - hex p/ dec, 2 - dec p/ hex): ");
		int op = sc.nextInt();

		System.out.println("Informe um número: ");
		String num = sc.next();
		int qtdc = num.length();
		int resto, a, resulDiv = 0;
		double pot = 0, tot = 0, result = 0;
		resto = a = 0;

		if (op == 1) {
			
			for (a = 0; a < qtdc; a++) {
				char litNum = num.charAt(a);
				pot = Math.pow(16, qtdc - 1 - a);
				int valor;
				if (Character.isDigit(litNum)) {
					valor = Character.getNumericValue(litNum);
				} else {
					valor = Character.toUpperCase(litNum) - 'A' + 10;
				}
				result = valor * pot;
				tot += result;
			}
			System.out.print(tot);
			
		} else if (op == 2) {
			int num1 = Integer.parseInt(num);
			String convert = "";
			int valor = 0;
			
			while(num1 > 0) {
				resto = num1 % 16;
				if (resto >= 10) {
					valor += 10;
				}
				resulDiv += num1;
				num1 = num1 / 16;
				System.out.print("Resultado: " + num1 + " Resto: " + resto + "\n");
				convert = resto + convert;
			}	
			System.out.print(convert);
		}
	}
}