package ppiL;

import java.util.Scanner;
import java.lang.Math;
import java.lang.Character;

public class ppi {
	public static void main(String[] args) {
		
	}
	
	}