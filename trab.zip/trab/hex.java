package trab;
import java.util.Scanner;
import java.lang.Math;
public class hex{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Selecione uma das opções: ");
		int op = sc.nextInt();
		
		System.out.println("Informe um número 1 - hex p/ dec: ");
		int num = sc.nextInt();
		String num1 = Integer.toString(num);
		int qtdc = num1.length();
		int resto, a;
		double tot = 0;
		resto = a = 0;
		
		if(op == 1) {
			System.out.print(qtdc + " " + num + "\n");
				for (a = 0; a < qtdc; a++) {
					char litNum = num1.charAt(a);
					System.out.print(litNum + "\n");
					tot = Math.pow(litNum, 0);
					System.out.print(tot);
					
					/* num = num / 16;
					resto = num % 16;
					System.out.println(num);
					System.out.println(resto); */
				}
		}
	}
}